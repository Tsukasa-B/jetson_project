"""FastAPI + WebSocket サーバ。

起動:
    python -m oc_demo.server --midi-dir midi --models-dir models --mock
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import adapter
from .policy import discover_models
from .runner import RunConfig, Runner, build_run_target
from .score import Score, scan_midi_dir

HERE = Path(__file__).resolve().parent
STATIC = HERE / "static"


class Settings:
    midi_dir: Path = Path("midi")
    models_dir: Path = Path("models")
    port_name: str = "/dev/ttyUSB0"
    use_hardware: bool = True
    default_model: Optional[str] = None
    bpm_min: float = 60.0
    bpm_max: float = 180.0


SETTINGS = Settings()
SONGS: dict[str, Score] = {}
MODELS: list[dict] = []
RUNNER: Optional[Runner] = None

app = FastAPI(title="PAM Robot OC Demo")


# ---------------------------------------------------------------------
LABELS: dict[str, str] = {}


def reload_assets() -> None:
    """MIDI・モデル・表示名を読み直す。

    表示名は <midi_dir>/labels.json（{"01_yonuchi": "四分打ち"} 形式）で上書きできる。
    OC当日に来場者向けの曲名を出したいときはここを編集する。
    """
    global SONGS, MODELS, LABELS
    SONGS = {s.name: s for s in scan_midi_dir(SETTINGS.midi_dir)}
    MODELS = discover_models(SETTINGS.models_dir)
    LABELS = {}
    lp = Path(SETTINGS.midi_dir) / "labels.json"
    if lp.exists():
        try:
            LABELS = {str(k): str(v) for k, v in json.loads(lp.read_text("utf-8")).items()}
        except Exception as exc:  # noqa: BLE001
            print(f"[oc_demo] labels.json を読めませんでした: {exc}")


@app.on_event("startup")
async def _startup() -> None:
    reload_assets()
    print(f"[oc_demo] songs={len(SONGS)} models={len(MODELS)} "
          f"hardware={SETTINGS.use_hardware}")


# ---------------------------------------------------------------------
@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/api/health")
async def health() -> JSONResponse:
    return JSONResponse(
        {
            "ok": True,
            "hardware": SETTINGS.use_hardware,
            "port": SETTINGS.port_name,
            "n_songs": len(SONGS),
            "n_models": len(MODELS),
            "adapter": dict(adapter.STATUS),
            "bpm_range": [SETTINGS.bpm_min, SETTINGS.bpm_max],
            "state": RUNNER.state if RUNNER else "idle",
        }
    )


@app.get("/api/songs")
async def songs() -> JSONResponse:
    return JSONResponse(
        [
            {
                "name": s.name,
                "label": LABELS.get(s.name, s.name),
                "nominal_bpm": round(s.nominal_bpm, 1),
                "duration": round(s.duration, 2),
                "n_notes": len(s.notes),
                "lanes": s.lanes,
            }
            for s in SONGS.values()
        ]
    )


def song_payload(s: Score, bpm: float, lead_in: float = 1.5) -> dict:
    """譜面 + 目標力軌道。どちらも lead_in ぶんずらした「演奏時刻」で返す。"""
    played = s.rescaled(bpm)
    target, _ = build_run_target(s, bpm, lead_in, 1.0)
    d = played.to_dict()
    for n in d["notes"]:
        n["t"] = round(n["t"] + lead_in, 4)
    d["lead_in"] = lead_in
    d["dt"] = 0.02
    d["target"] = [round(float(v), 3) for v in target]
    return d


@app.get("/api/song/{name}")
async def song(name: str, bpm: Optional[float] = None,
               lead_in: float = 1.5) -> JSONResponse:
    s = SONGS.get(name)
    if s is None:
        raise HTTPException(404, f"unknown song: {name}")
    return JSONResponse(song_payload(s, float(bpm or s.nominal_bpm), lead_in))


@app.get("/api/models")
async def models() -> JSONResponse:
    return JSONResponse(MODELS)


class StartReq(BaseModel):
    song: str
    bpm: Optional[float] = None
    model: Optional[str] = None
    lead_in: float = 1.5


@app.post("/api/start")
async def start(req: StartReq) -> JSONResponse:
    global RUNNER
    if RUNNER is not None and RUNNER.state in ("running", "arming"):
        raise HTTPException(409, "already running")
    s = SONGS.get(req.song)
    if s is None:
        raise HTTPException(404, f"unknown song: {req.song}")

    bpm = float(req.bpm or s.nominal_bpm)
    bpm = max(SETTINGS.bpm_min, min(SETTINGS.bpm_max, bpm))

    model_path = None
    model_id = req.model or SETTINGS.default_model
    if model_id:
        hit = next((m for m in MODELS if m["id"] == model_id or m["label"] == model_id), None)
        if hit is None:
            raise HTTPException(404, f"unknown model: {model_id}")
        model_path = hit["path"]

    cfg = RunConfig(
        score=s,
        bpm=bpm,
        model_path=model_path,
        port=SETTINGS.port_name,
        use_hardware=SETTINGS.use_hardware,
        lead_in=req.lead_in,
    )
    RUNNER = Runner(cfg)
    RUNNER.start()
    return JSONResponse({"ok": True, "bpm": bpm, "model": model_id,
                         "score": song_payload(s, bpm, req.lead_in)})


@app.post("/api/stop")
async def stop() -> JSONResponse:
    if RUNNER is None:
        return JSONResponse({"ok": True, "state": "idle"})
    RUNNER.stop()
    return JSONResponse({"ok": True, "state": RUNNER.state})


@app.websocket("/ws")
async def ws(socket: WebSocket) -> None:
    """20Hzでテレメトリを配信する。ブラウザが切れても演奏は止めない。"""
    await socket.accept()
    last_state = None
    cursor = 0
    seen_run = None
    seen_runner = None
    try:
        while True:
            if RUNNER is None:
                await socket.send_text(json.dumps({"type": "idle"}))
            else:
                # 新しい演奏が始まったらカーソルを巻き戻す（接続ごとに独立）
                if seen_runner is not RUNNER or seen_run != RUNNER.run_id:
                    cursor, seen_runner, seen_run = 0, RUNNER, RUNNER.run_id
                samples, hits, cursor = RUNNER.drain(cursor)
                snap = RUNNER.snapshot()
                payload = {"type": "tick", "s": samples, "hits": hits,
                           "run_id": RUNNER.run_id, **snap}
                if snap["state"] != last_state:
                    payload["state_changed"] = True
                    last_state = snap["state"]
                await socket.send_text(json.dumps(payload))
            await asyncio.sleep(0.05)
    except WebSocketDisconnect:
        return
    except Exception:  # noqa: BLE001
        return


app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


# ---------------------------------------------------------------------
def main() -> None:
    import uvicorn

    ap = argparse.ArgumentParser(description="PAM robot OC demo server")
    ap.add_argument("--midi-dir", default=os.environ.get("OC_MIDI_DIR", "midi"))
    ap.add_argument("--models-dir", default=os.environ.get("OC_MODELS_DIR", "models"))
    ap.add_argument("--port-name", default=os.environ.get("OC_SERIAL_PORT", "/dev/ttyUSB0"))
    ap.add_argument("--model", default=os.environ.get("OC_DEFAULT_MODEL"),
                    help="既定モデル（例 IROS/modelB.onnx）")
    ap.add_argument("--mock", action="store_true", help="実機に繋がずシミュレーションで動かす")
    ap.add_argument("--bpm-min", type=float, default=60.0)
    ap.add_argument("--bpm-max", type=float, default=180.0)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--http-port", type=int, default=8080)
    args = ap.parse_args()

    SETTINGS.midi_dir = Path(args.midi_dir)
    SETTINGS.models_dir = Path(args.models_dir)
    SETTINGS.port_name = args.port_name
    SETTINGS.use_hardware = not args.mock
    SETTINGS.default_model = args.model
    SETTINGS.bpm_min = args.bpm_min
    SETTINGS.bpm_max = args.bpm_max

    print(f"[oc_demo] http://{args.host}:{args.http_port}/  "
          f"({'MOCK' if args.mock else 'HARDWARE ' + args.port_name})")
    uvicorn.run(app, host=args.host, port=args.http_port, log_level="warning")


if __name__ == "__main__":
    main()
