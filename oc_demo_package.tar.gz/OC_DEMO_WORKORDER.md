# OCデモGUI（oc_demo）実装指示書

作成: 2026-07-30 / クラウド側で実装・モック検証済み、Jetson実機での結線は未実施。

来場者が **曲を選んで START を押すだけ** でロボットが演奏し、
**MIDI譜面と実際の打点タイミングが同じ画面に流れる** ブラウザUIです。

---

## 0. まず結論：Jetson側でやること3つ

1. `pip install -r oc_demo/requirements.txt`（コンテナ内）
2. `./run_oc_demo.sh --mock` で画面が出ることを確認（実機不要）
3. **§3 の「結線点3つ」を潰してから** 実機モードに入る

§3 を飛ばすと「動いてはいるが観測ベクトルが学習時とズレている」状態になり、
**静かに間違います**。実機に触る前に必ず確認してください。

---

## 1. 配置

`jetson_project` のルート直下に展開します。既存ファイルは1つも書き換えません。

```
jetson_project/
├── run_rl_deploy_midi.py      ← 既存。触らない
├── midi_rhythm_generator.py   ← 既存。oc_demo から参照する
├── models/                    ← 既存
├── midi/                      ← MIDI置き場（無ければ作る）
│   └── labels.json            ← 表示名（任意）
├── run_oc_demo.sh             ← 追加
└── oc_demo/                   ← 追加
    ├── __init__.py
    ├── adapter.py    ★ 既存コードとの結線点。最初に読む
    ├── score.py        MIDI → 譜面 + 目標力軌道
    ├── plant.py        シリアルI/O（実機）/ 簡易シミュレータ（モック）
    ├── policy.py       ONNX推論 / モデル無し用スクリプト動作
    ├── runner.py       50Hz制御ループ + テレメトリ
    ├── server.py       FastAPI + WebSocket
    ├── requirements.txt
    └── static/index.html   画面（1ファイル）
```

## 2. インストールと起動

```bash
# コンテナ内で
pip install -r oc_demo/requirements.txt

# (a) 実機なしで画面確認
./run_oc_demo.sh --mock

# (b) 実機
sudo modprobe ftdi_sio                                             # ホスト側
echo 0584 b050 | sudo tee /sys/bus/usb-serial/drivers/ftdi_sio/new_id
./run_oc_demo.sh                                                   # コンテナ内
```

ブラウザで `http://localhost:8080/`。別PC/タブレットからは `http://<JetsonのIP>:8080/`。
コンテナは `--network host` なので `-p` の追加は不要です。

複数のブラウザから同時に開いて構いません（全画面が同じ演奏をミラーします）。

会場では Chromium を全画面で:
```bash
chromium-browser --kiosk --app=http://localhost:8080/
```

---

## 3. ★結線点3つ（実機前に必ず）

### 3-1. 目標力軌道が既存実装と一致しているか

`oc_demo/adapter.py::build_target_force()` は `midi_rhythm_generator` から
以下の名前の関数を順に探します。

```
generate_target_force_trajectory / generate_target_force /
midi_to_target_force / build_target_force
```

**どれとも一致しなければ `score.py` のフォールバック実装（raised-cosine パルス）が
使われます。** これは sim の学習時と別物です。

確認方法:
```bash
curl -s localhost:8080/api/health | python3 -m json.tool
# adapter.target_force が "fallback:..." なら未結線
```
実関数名を確認して `adapter.py` の候補リストに追加するか、直接呼び出しに書き換えてください。
引数が `(path, bpm=..., n_steps=..., dt=...)` と違う場合も同様です。

### 3-2. 観測ベクトルが `run_rl_deploy_midi.py` と一致しているか

`adapter.py::build_obs()` は調査メモ §3 の仕様で実装してあります。

```
obs = [q_wrist, q_grip, qd_wrist, qd_grip, prev_action(3),
       sin(phase), cos(phase), bpm/180, lookahead(L)]     L = obs_dim - 10
```

- `prev_action` は **clip後** の値を入れています（実機の既存実装と同じ）
- `qd` は 角度差分/0.02 を ±20 rad/s clip
- `lookahead` は `target_force` の最大値で正規化（0〜1）
- `LOOKAHEAD_STEPS` は **ONNXの入力次元から自動導出**（ハードコードしていません）

`tools/parity_test.py` と同じ要領で、同一のセンサ系列を
`run_rl_deploy_midi.py` の経路と `oc_demo` の経路に通し、obs がビット一致することを
確認してください。ズレていれば `adapter.build_obs` を直します。

### 3-3. 力センサのゼロ点

`jetson_refactor_v2_20260730.md` の未解決事項です（無負荷で `force_N ≈ -20.0`、
IROS時は -0.1〜-0.3）。**±30ms判定に直結します。**

oc_demo は演奏開始直前に50フレームを読んで中央値をゼロ点として引きます
（`RunConfig.zero_force_samples`）。画面左下と `/api/health` に実測値が出ます。

- これは **その瞬間が無負荷である** ことが前提です。スティックが打面に触れた状態で
  STARTすると、そのぶんが丸ごとオフセットになります
- ゼロ点が -20 N 付近のままなら、原因（配線/アンプ/Simulink側スケール）を
  先に潰してください。デモの数字が全部意味を失います

---

## 4. このデモが**やらない**こと

- **論文E（frame stacking, obs 175次元）は非対応**です。読み込もうとすると
  `policy.py` が明示的に例外を投げます（黙って誤った obs を作らないため）。
  対応するには 直近5フレーム × 35次元 のリングバッファを `policy.py` に実装し、
  並びを `[最古 … 最新]`（最新が末尾）にします
- LSTM の h0/c0 は演奏ごとにゼロ初期化します（1曲=1セッション運用）
- ログの CSV 保存はしていません。必要なら `runner.Runner.samples` を落としてください

## 5. 安全まわり

| 項目 | 実装 |
|---|---|
| 緊急停止 | 画面に常時「ストップ（緊急停止）」。押すと制御ループが抜けて圧力0を2回送信 |
| 異常力 | `force_limit_N=60.0` を超えると自動停止し画面にエラー表示 |
| 終了時 | 正常終了・例外・停止のいずれでも `plant.close()` で圧力0 |
| ブラウザ切断 | 演奏は止めません（画面が落ちてもロボットは曲を弾き切る）。**物理の非常停止は別途会場に用意してください** |
| BPM範囲 | `--bpm-min/--bpm-max`（既定 60〜180）。学習範囲外に出さないよう当日設定を絞ること |

来場者に開放するのは「曲選択」と「テンポ」と「START」だけです。
モデル選択はUIに出していません（既定モデルは `run_oc_demo.sh` の `OC_MODEL`）。

## 6. OC当日の準備

1. `midi/` に流す曲（.mid）を置く。1曲15〜25秒程度が回転が良い
2. `midi/labels.json` に来場者向けの日本語名を書く
   ```json
   {"01_yonuchi": "四分打ち（かんたん）", "03_rock": "ロックビート"}
   ```
3. MIDIのピッチは GM ドラムマップで表示名が付きます（38=スネア, 42=ハイハット…）
4. Jetsonの時刻合わせ（`sudo date -s ...`）を忘れずに
5. 開場前に `--mock` で一度通し、そのあと実機で全曲を1回ずつ通す

## 7. 画面の見方（来場者への説明用）

- **青いバー** = 楽譜。右から流れてきて、白い縦線（いま）に来た瞬間が叩くタイミング
- **青い山** = そのとき出したい力
- **黄色い線** = 力センサが実際に測った力
- **緑/赤の点** = 実際の打点。緑は楽譜から ±30ms 以内、赤は外れ
- **右下の%** = ±30ms 以内に入った打点の割合

「人間のドラマーの許容ズレが±30ms程度」という枕を振ると伝わりやすいです。

## 8. 動作確認済みの範囲（クラウド側・モック）

- 5曲 × BPM 90/120/160 で通し再生、打点検出・±30ms判定が動作
- ブラウザ2枚同時接続でテレメトリが欠落しないこと
- 1920×1080 / 1600×900 / 1280×800 でレイアウト崩れなし
- 演奏中のブラウザリロード、演奏終了後の連続スタート

**未確認（Jetson側でお願いします）**: 実シリアル通信、ONNX実モデルでの推論、
Jetson上での描画性能、力センサゼロ点。
